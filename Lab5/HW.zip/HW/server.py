from flask import Flask, render_template
import pandas as pandas
import json

app = Flask(__name__)

@app.route("/")
def index():
    file = pandas.read_csv('data.csv').drop('Open', axis=1)
    data = file.to_dict(orient='records')
    data = json.dumps(data, indent=2)
    chartData = {'chart_data': data}
    return render_template("index.html", data=chartData)


if __name__ == "__main__":
    app.run(debug=True)

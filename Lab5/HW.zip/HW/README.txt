HOW TO RUN IT:

First, make sure the directory is where the folder located, then:

pip3 install -r package.txt
python3 server.py

Have fun :)